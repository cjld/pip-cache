#ifndef __KTYPES_H
#define __KTYPES_H

/* compipler specific configuration */

#endif /* __KTYPES_H */
